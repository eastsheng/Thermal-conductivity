#1. python setup.py sdist
#2. python setup.py install
from distutils.core import setup

setup(

	name         = 'thermal_conductivity',
	version      = '1.1.4',
	py_modules   = ['thermal_conductivity'],
	author       = 'DongshengChen',
	author_email = 'eastsheng@hotmail.com',
	url          = 'https://github.com/eastsheng',
	description  = 'Calculate thermal conductivity about NEMD dump.'
	)

#3. register PyPI(http://pypi.python.org/)
#4. cmd:'setup.py register',
#5. python setup.py sdist upload
